// =======================================
// AL-FURQAAN ISLAMIC SCHOOL
// Website JavaScript
// =======================================

// 1. MOBILE MENU
const menuBtn = document.getElementById("menuBtn");
const nav = document.getElementById("nav");

if (menuBtn && nav) {
    menuBtn.addEventListener("click", function () {
        nav.classList.toggle("active");

        const isOpen = nav.classList.contains("active");

        menuBtn.textContent = isOpen ? "✕" : "☰";
        menuBtn.setAttribute("aria-expanded", isOpen);
    });

    nav.querySelectorAll("a").forEach(function (link) {
        link.addEventListener("click", function () {
            nav.classList.remove("active");
            menuBtn.textContent = "☰";
            menuBtn.setAttribute("aria-expanded", "false");
        });
    });
}

// 2. CURRENT YEAR
const yearElement = document.getElementById("year");

if (yearElement) {
    yearElement.textContent = new Date().getFullYear();
}

// 3. LANGUAGE TRANSLATIONS
const translations = {
    om: {
        home: "Mana",
        about: "Waa'ee Keenya",
        courses: "Barnoota",
        contact: "Nu Qunnamaa",
        register: "Galmaa'i",
        chooseLanguage: "Afaan filadhu:",
        welcome: "Baga Gara Keenya Dhuftan!",
        heroTitle: 'Beekumsa Baradhu, <span>Amala Gaarii Ijaaradhu.</span>',
        heroText: "Mana Barumsaa Islaamaa Al-Furqaan keessatti beekumsa Islaamaa, naamusa gaarii fi barnoota bu'a qabeessa ta'e argadhu.",
        startLearning: "Amma Galmaa'i",
        learnMore: "Dabalataan Baradhu",
        quality: "Barnoota Qulqulluu",
        character: "Amala Gaarii",
        future: "Egeree Ifaa",
        knowledge: "Beekumsi Ifa",
        aboutUs: "Waa'ee Keenya",
        aboutTitle: "Barnoota, Amala fi Milkaa'ina",
        aboutText: "Al-Furqaan Islamic School barattoonni beekumsa argatan, amala gaarii horatan, akkasumas egeree isaanii ijaaratan deeggaruuf kan kaayyeffatedha.",
        quran: "Barnoota Qur'aanaa",
        quranText: "Qur'aana sirnaan qara'uu fi Tajwiida barachuu.",
        islamic: "Barnoota Islaamaa",
        islamicText: "Fiqhii, Siiraa fi naamusa Islaamaa barachuu.",
        development: "Guddina Barattootaa",
        developmentText: "Beekumsa, dandeettii fi amala gaarii cimsachuu.",
        ourCourses: "Barnoota Keenya",
        coursesTitle: "Barnoota Filannoo Keessan",
        coursesText: "Barnoota bu'uuraa fi Islaamaa barattootaaf qophaa'e.",
        courseQuran: "Qur'aana",
        courseQuranText: "Qara'aa fi Hifzii Qur'aanaa.",
        tajweed: "Tajwiida",
        tajweedText: "Seera sirrii ittiin Qur'aana qara'an.",
        fiqh: "Fiqhii fi Siiraa",
        fiqhText: "Beekumsa amantii fi seenaa Nabiyyii ﷺ.",
        languages: "Afaanota",
        languagesText: "Afaan Arabaa fi barnoota dabalataa.",
        joinUs: "Nu Waliin Baradhaa",
        registerTitle: "Barataa Ta'uu Barbaadduu?",
        registerText: "Odeeffannoo galmee barattootaa argachuuf nu qunnamaa.",
        contactUs: "Nu Qunnamaa",
        contactTitle: "Nu Waliin Wal Qunnamaa",
        locationText: "Gooroo, Godina Baalee, Oromiyaa, Itoophiyaa.",
        ourLocation: "Bakka Keenya",
        footerText: "Barnoota gaarii, amala gaarii fi egeree ifaa.",
        rights: "Mirgi hundi eegamaadha."
    },

    en: {
        home: "Home",
        about: "About Us",
        courses: "Courses",
        contact: "Contact",
        register: "Register",
        chooseLanguage: "Choose language:",
        welcome: "WELCOME TO OUR SCHOOL!",
        heroTitle: 'Learn Knowledge, <span>Build Good Character.</span>',
        heroText: "Discover Islamic knowledge, good character and meaningful education at Al-Furqaan Islamic School.",
        startLearning: "Register Now",
        learnMore: "Learn More",
        quality: "Quality Education",
        character: "Good Character",
        future: "Bright Future",
        knowledge: "Knowledge is Light",
        aboutUs: "About Us",
        aboutTitle: "Education, Character and Success",
        aboutText: "Al-Furqaan Islamic School aims to help students gain knowledge, develop good character and build a brighter future.",
        quran: "Qur'an Education",
        quranText: "Learn Qur'an recitation and Tajweed.",
        islamic: "Islamic Studies",
        islamicText: "Learn Fiqh, Seerah and Islamic manners.",
        development: "Student Development",
        developmentText: "Build knowledge, skills and good character.",
        ourCourses: "Our Courses",
        coursesTitle: "Explore Our Courses",
        coursesText: "Foundational and Islamic learning for students.",
        courseQuran: "Qur'an",
        courseQuranText: "Qur'an recitation and memorization.",
        tajweed: "Tajweed",
        tajweedText: "Rules for correct Qur'an recitation.",
        fiqh: "Fiqh and Seerah",
        fiqhText: "Islamic knowledge and the Prophet's biography ﷺ.",
        languages: "Languages",
        languagesText: "Arabic and additional learning.",
        joinUs: "Learn With Us",
        registerTitle: "Would You Like to Enroll?",
        registerText: "Contact us to learn about student registration.",
        contactUs: "Contact Us",
        contactTitle: "Get in Touch",
        locationText: "Gooroo, Bale Zone, Oromia, Ethiopia.",
        ourLocation: "Our Location",
        footerText: "Quality education, good character and a bright future.",
        rights: "All rights reserved."
    },

    am: {
        home: "መነሻ",
        about: "ስለ እኛ",
        courses: "ትምህርቶች",
        contact: "ያግኙን",
        register: "ይመዝገቡ",
        chooseLanguage: "ቋንቋ ይምረጡ:",
        welcome: "ወደ ትምህርት ቤታችን እንኳን በደህና መጡ!",
        heroTitle: 'እውቀትን ይማሩ፣ <span>መልካም ስነ-ምግባርን ይገንቡ።</span>',
        heroText: "በአል-ፉርቃን እስላማዊ ትምህርት ቤት የእስልምና እውቀትን፣ መልካም ስነ-ምግባርን እና ጠቃሚ ትምህርትን ያግኙ።",
        startLearning: "አሁን ይመዝገቡ",
        learnMore: "ተጨማሪ ይወቁ",
        quality: "ጥራት ያለው ትምህርት",
        character: "መልካም ስነ-ምግባር",
        future: "ብሩህ የወደፊት ሕይወት",
        knowledge: "እውቀት ብርሃን ነው",
        aboutUs: "ስለ እኛ",
        aboutTitle: "ትምህርት፣ ስነ-ምግባር እና ስኬት",
        aboutText: "አል-ፉርቃን እስላማዊ ትምህርት ቤት ተማሪዎች እውቀት እንዲያገኙ፣ መልካም ስነ-ምግባር እንዲያዳብሩ እና የወደፊት ሕይወታቸውን እንዲገነቡ ይረዳል።",
        quran: "የቁርአን ትምህርት",
        quranText: "ቁርአንን በትክክል ማንበብና ተጅዊድ መማር።",
        islamic: "እስላማዊ ትምህርት",
        islamicText: "ፊቅህ፣ ሲራ እና እስላማዊ ስነ-ምግባር መማር።",
        development: "የተማሪዎች እድገት",
        developmentText: "እውቀትን፣ ክህሎትን እና መልካም ስነ-ምግባርን ማዳበር።",
        ourCourses: "ትምህርቶቻችን",
        coursesTitle: "የምንሰጣቸው ትምህርቶች",
        coursesText: "ለተማሪዎች የተዘጋጁ መሠረታዊና እስላማዊ ትምህርቶች።",
        courseQuran: "ቁርአን",
        courseQuranText: "ቁርአንን ማንበብና ማስታወስ።",
        tajweed: "ተጅዊድ",
        tajweedText: "ቁርአንን በትክክል ለማንበብ የሚያግዙ ሕጎች።",
        fiqh: "ፊቅህ እና ሲራ",
        fiqhText: "የእስልምና እውቀትና የነቢዩ ﷺ ታሪክ።",
        languages: "ቋንቋዎች",
        languagesText: "የዐረብኛ ቋንቋና ተጨማሪ ትምህርቶች።",
        joinUs: "ከእኛ ጋር ይማሩ",
        registerTitle: "ተማሪ መሆን ይፈልጋሉ?",
        registerText: "ስለ ተማሪ ምዝገባ መረጃ ለማግኘት ያግኙን።",
        contactUs: "ያግኙን",
        contactTitle: "እኛን ያግኙ",
        locationText: "ጎሮ፣ ባሌ ዞን፣ ኦሮሚያ፣ ኢትዮጵያ።",
        ourLocation: "አድራሻችን",
        footerText: "ጥራት ያለው ትምህርት፣ መልካም ስነ-ምግባር እና ብሩህ የወደፊት ሕይወት።",
        rights: "መብቱ በሙሉ የተጠበቀ ነው።"
    },

    ar: {
        home: "الرئيسية",
        about: "من نحن",
        courses: "الدورات",
        contact: "اتصل بنا",
        register: "التسجيل",
        chooseLanguage: "اختر اللغة:",
        welcome: "مرحبًا بكم في مدرستنا!",
        heroTitle: 'تعلّم المعرفة، <span>وابنِ الأخلاق الحميدة.</span>',
        heroText: "اكتسب المعرفة الإسلامية والأخلاق الحميدة والتعليم النافع في مدرسة الفرقان الإسلامية.",
        startLearning: "سجّل الآن",
        learnMore: "اعرف المزيد",
        quality: "تعليم عالي الجودة",
        character: "الأخلاق الحميدة",
        future: "مستقبل مشرق",
        knowledge: "العلم نور",
        aboutUs: "من نحن",
        aboutTitle: "التعليم والأخلاق والنجاح",
        aboutText: "تهدف مدرسة الفرقان الإسلامية إلى مساعدة الطلاب على اكتساب المعرفة وتنمية الأخلاق الحميدة وبناء مستقبل أفضل.",
        quran: "تعليم القرآن",
        quranText: "تعلّم تلاوة القرآن الكريم والتجويد.",
        islamic: "الدراسات الإسلامية",
        islamicText: "تعلّم الفقه والسيرة والأخلاق الإسلامية.",
        development: "تنمية الطلاب",
        developmentText: "تنمية المعرفة والمهارات والأخلاق الحميدة.",
        ourCourses: "دوراتنا",
        coursesTitle: "اكتشف برامجنا التعليمية",
        coursesText: "تعليم أساسي وإسلامي مُعدّ للطلاب.",
        courseQuran: "القرآن الكريم",
        courseQuranText: "تلاوة القرآن الكريم وحفظه.",
        tajweed: "التجويد",
        tajweedText: "قواعد التلاوة الصحيحة للقرآن الكريم.",
        fiqh: "الفقه والسيرة",
        fiqhText: "المعرفة الإسلامية وسيرة النبي ﷺ.",
        languages: "اللغات",
        languagesText: "اللغة العربية ودروس إضافية.",
        joinUs: "تعلّم معنا",
        registerTitle: "هل ترغب في التسجيل؟",
        registerText: "اتصل بنا لمعرفة معلومات تسجيل الطلاب.",
        contactUs: "اتصل بنا",
        contactTitle: "تواصل معنا",
        locationText: "غورو، منطقة بالي، أوروميا، إثيوبيا.",
        ourLocation: "موقعنا",
        footerText: "تعليم جيد وأخلاق حسنة ومستقبل مشرق.",
        rights: "جميع الحقوق محفوظة."
    }
};

// 4. CHANGE LANGUAGE
const languageSelect = document.getElementById("language");

function changeLanguage(language) {
    const dictionary = translations[language];

    if (!dictionary) {
        return;
    }

    // Change document language and direction.
    document.documentElement.lang = language;
    document.documentElement.dir = language === "ar" ? "rtl" : "ltr";
    document.body.dir = language === "ar" ? "rtl" : "ltr";

    // Translate every element with a matching data-key.
    document.querySelectorAll("[data-key]").forEach(function (element) {
        const key = element.dataset.key;

        if (dictionary[key] !== undefined) {
            element.innerHTML = dictionary[key];
        }
    });

    // Remember the selected language on this device.
    try {
        localStorage.setItem("alfurqaan-language", language);
    } catch (error) {
        // The site can still work if local storage is unavailable.
    }
}

if (languageSelect) {
    languageSelect.addEventListener("change", function () {
        changeLanguage(this.value);
    });

    let savedLanguage = "om";

    try {
        savedLanguage = localStorage.getItem("alfurqaan-language") || "om";
    } catch (error) {
        savedLanguage = "om";
    }

    if (translations[savedLanguage]) {
        languageSelect.value = savedLanguage;
        changeLanguage(savedLanguage);
    } else {
        changeLanguage("om");
    }
}
// Student registration form demonstration
const studentForm = document.getElementById("studentForm");
const formMessage = document.getElementById("formMessage");

if (studentForm && formMessage) {
    studentForm.addEventListener("submit", function (event) {
        event.preventDefault();

        if (!studentForm.checkValidity()) {
            studentForm.reportValidity();
            return;
        }

        formMessage.textContent =
            "Unki sirriitti guutameera. Galmeen online amma hin banamne.";

        formMessage.style.color = "#075b43";
    });
}